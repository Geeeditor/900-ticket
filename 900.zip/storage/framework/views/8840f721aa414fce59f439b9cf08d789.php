<?php $__env->startSection('title', 'Manage Users'); ?>;
<?php $__env->startSection('content'); ?>
    
                <div class="my-2">
                    <div class="overflow-x-auto">
                        <div class="shadow-md rounded-lg">
                            <h1 class="font-[700] uppercase">900 TICKET USERS LIST</h1>


                                <table class="w-full table-auto">
                                <thead class="uppercase bg-gray-700 text-white">
                                    <tr>
                                        <th class="py-2 px-4 text-left">User ID</th>
                                        <th class="py-2 px-4 text-left">Name</th>
                                        <th class="py-2 px-4 text-left">Email</th>
                                        <th class="py-2 px-4 text-left">Total Completed Orders</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white text-gray-500">
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="py-2">
                                        <td class="px-4"><?php echo e($users->id); ?></td>
                                        <td class="px-4"><?php echo e($users->firstname . ' ' . $users->lastname); ?></td>
                                        <td class="px-4"><?php echo e($users->email); ?></td>
                                        <td class="px-4">N/A</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="mt-[15px]">
                    <div class="flex items-center flex-col justify-center gap-0">
                        <img src="<?php echo e(asset('image/error.svg')); ?>" alt="lorem ipsum">
                        Sorry no registers users
                        <div class="text-[13px] font-[300]">
                            <a href="<?php echo e(route('admin.create.event')); ?>">Create an account </a>
                        </div>
                    </div>
                </div>
                  <?php endif; ?>
                                </tbody>
                            </table>







                        </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Websites\901-ticket\900-ticket\resources\views/admin/pages/userList.blade.php ENDPATH**/ ?>