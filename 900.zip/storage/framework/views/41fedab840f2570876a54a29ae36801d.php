<?php $__env->startSection('title', 'Admin Management Page'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="flex flex-wrap py-1 md:py-0">
                    <div class="w-full md:w-1/2 md:p-2">
                        <a href="<?php echo e(route('admin.users')); ?>" class="block bg-gray-200 p-4 md:p-10 shadow-sm shadow-gray-400 hover:scale-[1.03] duration-75 font-[700]  rounded-md uppercase  text-[20px]">
                            <img src="<?php echo e(asset('image/profile.svg')); ?>" alt="profile">
                            Total Users
                            <span class="font-sans ">
                                <?php echo e($totalUsers); ?>

                            </span>
                        </a>
                    </div>
                    <div class="w-full md:w-1/2 md:p-2">
                        <a href="javascript:void(0)" class="block bg-gray-200 p-4 md:p-10 shadow-sm shadow-gray-400 hover:scale-[1.03] duration-75 font-[700] rounded-md">
                            <img src="<?php echo e(asset('image/order.svg')); ?>" alt="Manage Order">
                            Manage Orders
                        </a>
                    </div>
                    <div class="w-full md:w-1/2 md:p-2">
                        <a href="javascript:void(0)" class="block bg-gray-200 p-4 md:p-10 shadow-sm shadow-gray-400 hover:scale-[1.03] duration-75 font-[700] rounded-md">
                            <img src="<?php echo e(asset('image/complaints.svg')); ?>" alt="Complaints Desk">
                            Complaints Desk
                        </a>
                    </div>
                    <div class="w-full md:w-1/2 md:p-2">
                        <a href="javascript:void(0)" class="block bg-gray-200 p-4 md:p-10 shadow-sm shadow-gray-400 hover:scale-[1.03] duration-75 font-[700] rounded-md">
                            <img src="<?php echo e(asset('image/message.svg')); ?>" alt="Announcement">
                            Send an Announcement
                        </a>
                    </div>
                </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Websites\901-ticket\900-ticket\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>