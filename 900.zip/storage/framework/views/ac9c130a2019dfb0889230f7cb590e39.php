<?php $__env->startSection('title', 'Update Event'); ?>
<?php $__env->startSection('content'); ?>
    <form method="post" action="<?php echo e(route('admin.events.edit.update', ['id' => $event->id] )); ?>"
        class="font-[sans-serif] max-w-4xl mx-auto py-5 px-5 flex flex-col md:gap-3 gap-2" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="font-[600] event-hero leading-normal text-[20px]">UPDATE EVENT</div>

        <?php if(session('error')): ?>
            <div class="flex flex-col gap-1 capitalize">
                <span class="text-[12px] font-[200] text-red-700">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?> !!!
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>

                <span class="text-[12px] font-[200] text-red-700">
                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?> !!!
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>

                <span class="text-[12px] font-[200] text-red-700">
                    <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?> !!!
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>

                <span class="text-[12px] font-[200] text-red-700">
                    <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?> !!!
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>

                <span class="text-[12px] font-[200] text-red-700">
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?> !!!
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>



                <span class="text-[12px] font-[200] text-red-700">
                    <?php $__errorArgs = ['map_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?> !!!
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>

                <span class="text-[12px] font-[200] text-red-700">
                    <?php $__errorArgs = ['hero_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?> !!!
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>

                <span class="text-[12px] font-[200] text-red-700">
                    <?php $__errorArgs = ['ticket_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?> !!!
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>

                <span class="text-[12px] font-[200] text-red-700">
                    <?php echo e(session('error')); ?>

                </span>
            </div>


        <?php endif; ?>

        <?php if(session()->has('success')): ?>
        <div>
              <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <div class="w-full">
            <div class="flex flex-wrap md:flex-nowrap h-fit align-items-start w-[100%] md:gap-4 gap-2">
                <div class="relative flex items-start content-start w-full md:w-1/2">

                    <input type="text" placeholder="Add Event Title" name="title"
                        class="px-4 py-3 bg-[#f0f1f2] focus:bg-transparent text-black w-full text-sm border outline-red-alt-800 rounded transition-all"
                        value="<?php echo e($event->title); ?>" />
                    <img class="w-[13px] -ml-[25px] mt-[15px]" src="<?php echo e(asset('image/title.svg')); ?>" alt="lorem ipsum">

                </div>


                <div class="relative flex items-start flex-col w-full md:w-1/2">
                    <input type="date" name="date"
                        class="px-4 py-3 bg-[#f0f1f2] focus:bg-transparent text-black w-full text-sm border outline-red-alt-800 rounded transition-all"
                        value="<?php echo e($event->date); ?>" />
                    <span class="font-[100] text-[10px] text-[#7f7f80] py-1">Pick Event Date</span>

                </div>
            </div>
        </div>

        <div class="w-full">
            <div class="flex flex-wrap md:flex-nowrap h-fit align-items-start w-[100%] md:gap-4 gap-2">
                <div class="relative flex items-start content-start w-full md:w-1/2">
                    <input type="text" placeholder="Add Detailed Event Venue Address" name="location"
                        class="px-4 py-3 bg-[#f0f1f2] focus:bg-transparent text-black w-full text-sm border outline-red-alt-800 rounded transition-all"
                        value="<?php echo e($event->location); ?>" />
                    <img class="w-[13px] -ml-[25px] mt-[15px]" src="<?php echo e(asset('image/location.svg')); ?>" alt="lorem ipsum">

                </div>

                <div class="relative flex items-start flex-col w-full md:w-1/2">
                    <input type="time" name="time"
                        class="px-4 py-3 bg-[#f0f1f2] focus:bg-transparent text-black w-full text-sm border outline-red-alt-800 rounded transition-all"
                        value="<?php echo e($event->time); ?>" />
                    <span class="font-[100] text-[10px] text-[#7f7f80] py-1">Pick Event Time</span>

                </div>
            </div>
        </div>

        <div class="w-full">
            <div class="flex flex-wrap md:flex-nowrap h-fit align-items-start w-[100%] md:gap-4 gap-2">


                <div class="relative flex items-start flex-col w-full md:w-1/2">
                    <textarea type="text" placeholder="Add Event Title" name="description"
                        class="px-4 py-3 bg-[#f0f1f2] focus:bg-transparent text-black w-full text-sm border outline-red-alt-800 rounded transition-all">
                        <?php echo e($event->description); ?>

                    </textarea>
                    <span class="font-[100] text-[10px] text-[#7f7f80] py-1">Provide Detailed Event Description</span>

                </div>

                <div class="relative flex items-start content-start w-full md:w-1/2">
                    <input type="number" placeholder="Enter Events Price" name="ticket_price"
                        class="px-4 py-3 bg-[#f0f1f2] focus:bg-transparent text-black w-full text-sm border outline-red-alt-800 rounded transition-all"
                        value="<?php echo e($event->ticket_price); ?>" />
                    <img class="w-[13px] -ml-[25px] mt-[15px]" src="<?php echo e(asset('image/price.svg')); ?>" alt="lorem ipsum">

                </div>
            </div>
        </div>

        <div class="w-full">
            <div class="flex flex-wrap md:flex-nowrap h-fit align-items-start w-[100%] md:gap-4 gap-2">
                <div class="relative flex items-start content-start w-full md:w-1/2">
                    <input type="url" placeholder="Provide Map Link" name="map_link"
                        class="px-4 py-3 bg-[#f0f1f2] focus:bg-transparent text-black w-full text-sm border outline-red-alt-800 rounded transition-all"
                        value='<?php echo e($event->map_link); ?>' />
                    <img class="w-[13px] -ml-[25px] mt-[15px]" src="<?php echo e(asset('image/map-pin.svg')); ?>" alt="lorem ipsum">

                </div>

                <div class="relative flex items-start flex-col w-full md:w-1/2">

                    <div class="grid w-full max-w-xs items-center gap-1.5">

                        <div class="w-full">
                          <img class="object-contain" src="<?php echo e(asset('storage/'. $event->hero_image )); ?>" alt="lorem ipsum">
                        </div>

                        <input
                            class="flex w-full rounded-md border border-blue-300 border-input bg-white text-sm text-gray-400 file:border-0 file:bg-red-alt-800 file:text-white file:text-sm file:font-medium"
                            name="hero_image" type="file" id="picture"  />
                    </div>

                    <span class="font-[100] text-[10px] text-[#7f7f80] py-1">Upload Event Flier</span>


                </div>
            </div>
        </div>


        <button type="submit"
            class="mt-4 px-6 py-2.5 text-sm w-full bg-red-alt-800 hover:bg-red-alt-700 text-white rounded transition-all border border-white">Create
            Event</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Websites\901-ticket\900-ticket\resources\views/admin/pages/900Events/edit.blade.php ENDPATH**/ ?>