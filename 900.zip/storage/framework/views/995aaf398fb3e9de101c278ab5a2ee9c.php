<?php $__env->startSection('content'); ?>
    <section>
        <div class="font-[600] event-hero md:mb-10">VIEW EVENT LIST</div>

        <?php if(session()->has('message')): ?>{
            <span class="font-[600] text-[20px]"><?php echo e(session('message')); ?></span>
        }
        <?php endif; ?>


        <div class="flex flex-wrap max-w-full">
            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class=" w-full md:w-1/2 p-2">

                    <div class="flex flex-col rounded-xl bg-white text-gray-700 shadow-md">
                        <div
                            class="h-40 overflow-hidden rounded-xl bg-blue-gray-500 text-white shadow-lg shadow-blue-gray-500/40 bg-gradient-to-r from-blue-500 to-blue-600">
                            <img class="object-cover w-full h-full" src="<?php echo e(asset('storage/' . $event->hero_image)); ?>"
                                alt="lorem ipsum">
                        </div>
                        <div class="p-6">
                            <h5 class="text-xl font-semibold text-blue-gray-900">
                                <?php echo e($event->title); ?>

                            </h5>
                            <p class="text-base font-light leading-relaxed">
                                <?php echo e($event->description); ?>

                            </p>
                        </div>
                        <div class="p-6 -mt-4 pt-0 w-fit">

                            <div
                                class="flex overflow-hidden bg-white border divide-x rounded-lg rtl:flex-row-reverse dark:bg-gray-900 dark:border-gray-700 dark:divide-gray-700">
                                <button
                                    class="px-4 py-2 font-medium text-gray-600 transition-colors duration-200 sm:px-6 dark:hover:bg-gray-800 dark:text-gray-300 hover:bg-gray-100">
                                    <a href="<?php echo e(route('admin.event.view', $event->id )); ?>">
                                        <span class="mdi mdi-open-in-new"></span>
                                    </a>

                                </button>

                                <button
                                    class="px-4 py-2 font-medium text-gray-600 transition-colors duration-200 sm:px-6 dark:hover:bg-gray-800 dark:text-gray-300 hover:bg-gray-100">
                                     <a href="<?php echo e(route('admin.events.edit', ['id'=>$event])); ?>">
                                        <span class="mdi mdi-file-edit"></span>

                                    </a>
                                </button>

                                <button
                                    class="px-4 py-2 font-medium text-gray-600 transition-colors duration-200 sm:px-6 dark:hover:bg-gray-800 dark:text-gray-300 hover:bg-gray-100">
                                     <a href="">

                                        <span class="mdi mdi-delete-empty-outline"></span>
                                    </a>
                                </button>
                            </div>

                        </div>
                    </div>




                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div>
                    <div class="flex items-center flex-col justify-center gap-0">
                        <img src="<?php echo e(asset('image/error.svg')); ?>" alt="lorem ipsum">
                        Sorry no events created
                        <div class="text-[13px] font-[300]">
                            <a href="<?php echo e(route('admin.create.event')); ?>">Create an event</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>










    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Websites\901-ticket\900-ticket\resources\views/admin/pages/900Events/view.blade.php ENDPATH**/ ?>