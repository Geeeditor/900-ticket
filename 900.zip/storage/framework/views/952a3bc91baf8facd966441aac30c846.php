<?php $__env->startSection('title', 'Party Ticket'); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/pages/event-item.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/desktop.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">



<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <main class="party-ticket-main"> 
        <!-- desktop section  -->
        <div class="esktop-only-display">


            <section class="desktop-first-section">
                <div class="first-section-grid">
                    <div class="image-div">
                        <img src="" alt="album img">
                        
                    </div>
                    <div class="first-section-second-div">
                        <h1><?php echo e($events->title); ?></h1>

                        <div class="text-first-inner-div">
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none">
                                    <path
                                        d="M8 5.75C7.59 5.75 7.25 5.41 7.25 5V2C7.25 1.59 7.59 1.25 8 1.25C8.41 1.25 8.75 1.59 8.75 2V5C8.75 5.41 8.41 5.75 8 5.75Z"
                                        fill="#1F242F" />
                                    <path
                                        d="M16 5.75C15.59 5.75 15.25 5.41 15.25 5V2C15.25 1.59 15.59 1.25 16 1.25C16.41 1.25 16.75 1.59 16.75 2V5C16.75 5.41 16.41 5.75 16 5.75Z"
                                        fill="#1F242F" />
                                    <path
                                        d="M8.5 14.5003C8.37 14.5003 8.24 14.4703 8.12 14.4203C7.99 14.3703 7.89 14.3003 7.79 14.2103C7.61 14.0203 7.5 13.7703 7.5 13.5003C7.5 13.3703 7.53 13.2403 7.58 13.1203C7.63 13.0003 7.7 12.8903 7.79 12.7903C7.89 12.7003 7.99 12.6303 8.12 12.5803C8.48 12.4303 8.93 12.5103 9.21 12.7903C9.39 12.9803 9.5 13.2403 9.5 13.5003C9.5 13.5603 9.49 13.6303 9.48 13.7003C9.47 13.7603 9.45 13.8203 9.42 13.8803C9.4 13.9403 9.37 14.0003 9.33 14.0603C9.3 14.1103 9.25 14.1603 9.21 14.2103C9.02 14.3903 8.76 14.5003 8.5 14.5003Z"
                                        fill="#1F242F" />
                                    <path
                                        d="M12 14.4999C11.87 14.4999 11.74 14.4699 11.62 14.4199C11.49 14.3699 11.39 14.2999 11.29 14.2099C11.11 14.0199 11 13.7699 11 13.4999C11 13.3699 11.03 13.2399 11.08 13.1199C11.13 12.9999 11.2 12.8899 11.29 12.7899C11.39 12.6999 11.49 12.6299 11.62 12.5799C11.98 12.4199 12.43 12.5099 12.71 12.7899C12.89 12.9799 13 13.2399 13 13.4999C13 13.5599 12.99 13.6299 12.98 13.6999C12.97 13.7599 12.95 13.8199 12.92 13.8799C12.9 13.9399 12.87 13.9999 12.83 14.0599C12.8 14.1099 12.75 14.1599 12.71 14.2099C12.52 14.3899 12.26 14.4999 12 14.4999Z"
                                        fill="#1F242F" />
                                    <path
                                        d="M15.5 14.4999C15.37 14.4999 15.24 14.4699 15.12 14.4199C14.99 14.3699 14.89 14.2999 14.79 14.2099C14.75 14.1599 14.71 14.1099 14.67 14.0599C14.63 13.9999 14.6 13.9399 14.58 13.8799C14.55 13.8199 14.53 13.7599 14.52 13.6999C14.51 13.6299 14.5 13.5599 14.5 13.4999C14.5 13.2399 14.61 12.9799 14.79 12.7899C14.89 12.6999 14.99 12.6299 15.12 12.5799C15.49 12.4199 15.93 12.5099 16.21 12.7899C16.39 12.9799 16.5 13.2399 16.5 13.4999C16.5 13.5599 16.49 13.6299 16.48 13.6999C16.47 13.7599 16.45 13.8199 16.42 13.8799C16.4 13.9399 16.37 13.9999 16.33 14.0599C16.3 14.1099 16.25 14.1599 16.21 14.2099C16.02 14.3899 15.76 14.4999 15.5 14.4999Z"
                                        fill="#1F242F" />
                                    <path
                                        d="M8.5 18.0002C8.37 18.0002 8.24 17.9702 8.12 17.9202C8 17.8702 7.89 17.8002 7.79 17.7102C7.61 17.5202 7.5 17.2602 7.5 17.0002C7.5 16.8702 7.53 16.7402 7.58 16.6202C7.63 16.4902 7.7 16.3802 7.79 16.2902C8.16 15.9202 8.84 15.9202 9.21 16.2902C9.39 16.4802 9.5 16.7402 9.5 17.0002C9.5 17.2602 9.39 17.5202 9.21 17.7102C9.02 17.8902 8.76 18.0002 8.5 18.0002Z"
                                        fill="#1F242F" />
                                    <path
                                        d="M12 18.0002C11.74 18.0002 11.48 17.8902 11.29 17.7102C11.11 17.5202 11 17.2602 11 17.0002C11 16.8702 11.03 16.7402 11.08 16.6202C11.13 16.4902 11.2 16.3802 11.29 16.2902C11.66 15.9202 12.34 15.9202 12.71 16.2902C12.8 16.3802 12.87 16.4902 12.92 16.6202C12.97 16.7402 13 16.8702 13 17.0002C13 17.2602 12.89 17.5202 12.71 17.7102C12.52 17.8902 12.26 18.0002 12 18.0002Z"
                                        fill="#1F242F" />
                                    <path
                                        d="M15.5 17.9999C15.24 17.9999 14.98 17.8899 14.79 17.7099C14.7 17.6199 14.63 17.5099 14.58 17.3799C14.53 17.2599 14.5 17.1299 14.5 16.9999C14.5 16.8699 14.53 16.7399 14.58 16.6199C14.63 16.4899 14.7 16.3799 14.79 16.2899C15.02 16.0599 15.37 15.9499 15.69 16.0199C15.76 16.0299 15.82 16.0499 15.88 16.0799C15.94 16.0999 16 16.1299 16.06 16.1699C16.11 16.1999 16.16 16.2499 16.21 16.2899C16.39 16.4799 16.5 16.7399 16.5 16.9999C16.5 17.2599 16.39 17.5199 16.21 17.7099C16.02 17.8899 15.76 17.9999 15.5 17.9999Z"
                                        fill="#1F242F" />
                                    <path
                                        d="M20.5 9.83984H3.5C3.09 9.83984 2.75 9.49984 2.75 9.08984C2.75 8.67984 3.09 8.33984 3.5 8.33984H20.5C20.91 8.33984 21.25 8.67984 21.25 9.08984C21.25 9.49984 20.91 9.83984 20.5 9.83984Z"
                                        fill="#1F242F" />
                                    <path
                                        d="M16 22.75H8C4.35 22.75 2.25 20.65 2.25 17V8.5C2.25 4.85 4.35 2.75 8 2.75H16C19.65 2.75 21.75 4.85 21.75 8.5V17C21.75 20.65 19.65 22.75 16 22.75ZM8 4.25C5.14 4.25 3.75 5.64 3.75 8.5V17C3.75 19.86 5.14 21.25 8 21.25H16C18.86 21.25 20.25 19.86 20.25 17V8.5C20.25 5.64 18.86 4.25 16 4.25H8Z"
                                        fill="#1F242F" />
                                </svg>
                                <p>Sunday, December 8th 2024</p>
                            </span>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none">
                                    <path
                                        d="M12 22.75C6.07 22.75 1.25 17.93 1.25 12C1.25 6.07 6.07 1.25 12 1.25C17.93 1.25 22.75 6.07 22.75 12C22.75 17.93 17.93 22.75 12 22.75ZM12 2.75C6.9 2.75 2.75 6.9 2.75 12C2.75 17.1 6.9 21.25 12 21.25C17.1 21.25 21.25 17.1 21.25 12C21.25 6.9 17.1 2.75 12 2.75Z"
                                        fill="#1F242F" />
                                    <path
                                        d="M15.7096 15.9298C15.5796 15.9298 15.4496 15.8998 15.3296 15.8198L12.2296 13.9698C11.4596 13.5098 10.8896 12.4998 10.8896 11.6098V7.50977C10.8896 7.09977 11.2296 6.75977 11.6396 6.75977C12.0496 6.75977 12.3896 7.09977 12.3896 7.50977V11.6098C12.3896 11.9698 12.6896 12.4998 12.9996 12.6798L16.0996 14.5298C16.4596 14.7398 16.5696 15.1998 16.3596 15.5598C16.2096 15.7998 15.9596 15.9298 15.7096 15.9298Z"
                                        fill="#1F242F" />
                                </svg>
                                <p>3:00 PM - 11:30 PM WAT</p>
                            </span>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none">
                                    <path
                                        d="M11.9999 14.1704C9.86988 14.1704 8.12988 12.4404 8.12988 10.3004C8.12988 8.16043 9.86988 6.44043 11.9999 6.44043C14.1299 6.44043 15.8699 8.17043 15.8699 10.3104C15.8699 12.4504 14.1299 14.1704 11.9999 14.1704ZM11.9999 7.94043C10.6999 7.94043 9.62988 9.00043 9.62988 10.3104C9.62988 11.6204 10.6899 12.6804 11.9999 12.6804C13.3099 12.6804 14.3699 11.6204 14.3699 10.3104C14.3699 9.00043 13.2999 7.94043 11.9999 7.94043Z"
                                        fill="#1F242F" />
                                    <path
                                        d="M11.9997 22.76C10.5197 22.76 9.02969 22.2 7.86969 21.09C4.91969 18.25 1.65969 13.72 2.88969 8.33C3.99969 3.44 8.26969 1.25 11.9997 1.25C11.9997 1.25 11.9997 1.25 12.0097 1.25C15.7397 1.25 20.0097 3.44 21.1197 8.34C22.3397 13.73 19.0797 18.25 16.1297 21.09C14.9697 22.2 13.4797 22.76 11.9997 22.76ZM11.9997 2.75C9.08969 2.75 5.34969 4.3 4.35969 8.66C3.27969 13.37 6.23969 17.43 8.91969 20C10.6497 21.67 13.3597 21.67 15.0897 20C17.7597 17.43 20.7197 13.37 19.6597 8.66C18.6597 4.3 14.9097 2.75 11.9997 2.75Z"
                                        fill="#1F242F" />
                                </svg>
                                <p>Queen's Park, Water Corporation Drive/Trinity Avenue, Off Ligali Ayorinde St, Victoria
                                    Island, Lagos</p>
                            </span>
                        </div>

                        <h4>Details about this event</h4>

                        <div class="text-second-inner-div">
                            <h6>It's Fiesta SZN!</h6>

                            <blockquote>
                                Get ready for the party of the year—Pulse Fiesta! This ultimate celebration of young urban
                                culture, community, and good vibes is back, and it’s packed with excitement. Featuring live
                                performances from top African artists, a silent disco, dance showcases, comedy acts,
                                interactive games, and more. Come as your authentic self, ready to dance, vibe, and connect
                                with friends old and new in an unforgettable atmosphere!
                            </blockquote>

                            <h5>Don't miss out on the best way to wrap up 2024—grab your tickets before they’re gone!</h5>
                        </div>

                        <div class="text-third-inner-div">

                            <h4>Location Pics</h4>
                            
                            <button>
                                Google Map Link
                            </button>

                            
                        </div>
                    </div>
                </div>
            </section>





             <section class="w-full px-4 py-8  md:px-8 md:py-12">
                <form class="bg-white rounded-md shadow-md p-1" action="">
                    <div class="my-4 w-full">
                        <h3 class="font-[700] text-[20px] md:text-left text-center md:text-[25px] " style="text-transform: uppercase  !important">Make a Ticket Reservation</h3>
                    </div>

                    
                    <div class="flex gap-2 md:gap-4 md:flex-row flex-col">
                        
                        <div class="w-full md:w-1/2 flex flex-col gap-4">
                            
                            <div class="flex border rounded-lg bg-gray-100 border-gray-200  items-center">
                                <h3 class="text-[#1F242F] font-[700] text-[20px] w-2/3 py-2 px-4">
                                    Regular
                                </h3>

                                
                                <div class="w-1/3 bg-white py-2 px-4">
                                    <label for="quantity-input" class="block mb-2 text-lg font-medium text-gray-900 ">
                                        N 2,000
                                    </label>

                                    <div class="relative flex items-center max-w-[8rem]">
                                        <button type="button" id="decrement-button"
                                            data-input-counter-decrement="quantity-input"
                                            class="bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-s-lg p-3 h-11 focus:ring-gray-100 focus:ring-2 focus:outline-none">
                                            <svg class="w-3 h-3 text-gray-900" aria-hidden="true"
                                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 18 2">
                                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                                    stroke-width="2" d="M1 1h16" />
                                            </svg>
                                        </button>

                                        <input type="text" id="quantity-input" data-input-counter
                                            aria-describedby="helper-text-explanation"
                                            class="bg-gray-50 border-x-0 border-gray-300 h-11 text-center text-gray-900 text-sm focus:ring-blue-500 focus:border-blue-500 block w-full py-2.5"
                                            placeholder="999" required />

                                        <button type="button" id="increment-button"
                                            data-input-counter-increment="quantity-input"
                                            class="bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-e-lg p-3 h-11 focus:ring-gray-100 focus:ring-2 focus:outline-none">
                                            <svg class="w-3 h-3 text-gray-900" aria-hidden="true"
                                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 18 18">
                                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                                    stroke-width="2" d="M9 1v16M1 9h16" />
                                            </svg>
                                        </button>
                                    </div>

                                </div>

                            </div>

                            
                            <div class="flex border rounded-lg bg-gray-100 border-gray-200  items-center">
                                <h3 class="text-[#1F242F] font-[700] text-[20px] w-2/3 py-2 px-4">
                                    VIP
                                </h3>

                                
                                <div class="w-1/3 bg-white py-2 px-4">
                                    <label for="quantity-input" class="block mb-2 text-lg font-medium text-gray-900 ">
                                        N 20,000
                                    </label>

                                    <div class="relative flex items-center max-w-[8rem]">
                                        <button type="button" id="decrement-button"
                                            data-input-counter-decrement="quantity-input"
                                            class="bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-s-lg p-3 h-11 focus:ring-gray-100 focus:ring-2 focus:outline-none">
                                            <svg class="w-3 h-3 text-gray-900" aria-hidden="true"
                                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 18 2">
                                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                                    stroke-width="2" d="M1 1h16" />
                                            </svg>
                                        </button>

                                        <input type="text" id="quantity-input" data-input-counter
                                            aria-describedby="helper-text-explanation"
                                            class="bg-gray-50 border-x-0 border-gray-300 h-11 text-center text-gray-900 text-sm focus:ring-blue-500 focus:border-blue-500 block w-full py-2.5"
                                            placeholder="999" required />

                                        <button type="button" id="increment-button"
                                            data-input-counter-increment="quantity-input"
                                            class="bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-e-lg p-3 h-11 focus:ring-gray-100 focus:ring-2 focus:outline-none">
                                            <svg class="w-3 h-3 text-gray-900" aria-hidden="true"
                                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 18 18">
                                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                                    stroke-width="2" d="M9 1v16M1 9h16" />
                                            </svg>
                                        </button>
                                    </div>

                                </div>

                            </div>
                            
                            <div class="flex border rounded-lg bg-gray-100 border-gray-200  items-center">
                                <h3 class="text-[#1F242F] font-[700] text-[20px] w-2/3 py-2 px-4">
                                    VVIP
                                </h3>

                                
                                <div class="w-1/3 bg-white py-2 px-4">
                                    <label for="quantity-input" class="block mb-2 text-lg font-medium text-gray-900 ">
                                        N 50,000
                                    </label>

                                    <div class="relative flex items-center max-w-[8rem]">
                                        <button type="button" id="decrement-button"
                                            data-input-counter-decrement="quantity-input"
                                            class="bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-s-lg p-3 h-11 focus:ring-gray-100 focus:ring-2 focus:outline-none">
                                            <svg class="w-3 h-3 text-gray-900" aria-hidden="true"
                                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 18 2">
                                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                                    stroke-width="2" d="M1 1h16" />
                                            </svg>
                                        </button>

                                        <input type="text" id="quantity-input" data-input-counter
                                            aria-describedby="helper-text-explanation"
                                            class="bg-gray-50 border-x-0 border-gray-300 h-11 text-center text-gray-900 text-sm focus:ring-blue-500 focus:border-blue-500 block w-full py-2.5"
                                            placeholder="999" required />

                                        <button type="button" id="increment-button"
                                            data-input-counter-increment="quantity-input"
                                            class="bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-e-lg p-3 h-11 focus:ring-gray-100 focus:ring-2 focus:outline-none">
                                            <svg class="w-3 h-3 text-gray-900" aria-hidden="true"
                                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 18 18">
                                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                                    stroke-width="2" d="M9 1v16M1 9h16" />
                                            </svg>
                                        </button>
                                    </div>

                                </div>

                            </div>
                        </div>

                        
                        <div class="w-full md:w-1/2">
                            
                            <div class="flex flex-col gap-4">
                                <div class="flex flex-col justify-between">
                                    <div class="flex flex-col items-start w-full">
                                        
                                        <div class="flex items-center gap-2 justify-between w-full">
                                            <div class="flex gap-2 items-center w-2/3">
                                                <h3 class="font-[700]">Regular</h3>
                                                <small class="text-[5px]">
                                                    unit:
                                                    <span class="text-[10px]">
                                                        1x
                                                    </span>
                                                </small>
                                            </div>
                                            <div clqss="w-1/3 text-right">
                                                <h5 class="font-[700]">0.00</h5>
                                            </div>
                                        </div>
                                        
                                        <div class="flex items-center gap-2 justify-between w-full">
                                            <div class="flex gap-2 items-center w-2/3">
                                                <h3 class="font-[700]">VIP</h3>
                                                <small class="text-[5px]">
                                                    unit:
                                                    <span class="text-[10px]">
                                                        1x
                                                    </span>
                                                </small>
                                            </div>
                                            <div clqss="w-1/3 text-right">
                                                <h5 class="font-[700]">0.00</h5>
                                            </div>
                                        </div>
                                        
                                        <div class="flex items-center gap-2 justify-between w-full">
                                            <div class="flex gap-2 items-center w-2/3">
                                                <h3 class="font-[700]">VVIP</h3>
                                                <small class="text-[5px]">
                                                    unit:
                                                    <span class="text-[10px]">
                                                        1x
                                                    </span>
                                                </small>
                                            </div>
                                            <div clqss="w-1/3 text-right">
                                                <h5 class="font-[700]">0.00</h5>
                                            </div>
                                        </div>


                                    </div>
                                    <div class="w-full text-right">
                                        <small class="text-[60%] font-[300] ">NGN</small>
                                    </div>
                                </div>

                                <div class="flex justify-between">
                                    <div class="flex flex-col items-start w-2/3">
                                        <h3 class="font-[700]">Subtotal</h3>
                                    </div>
                                     <div class="w-1/3 text-right">
                                        <h5 class="font-[700]">0.00</h5>
                                        <small class="text-[60%] font-[300] ">NGN</small>
                                    </div>
                                </div>

                                <div class="flex justify-between">
                                    <div class="flex flex-col items-start w-2/3">
                                        <h3 class="font-[700]">Fees</h3>
                                    </div>
                                     <div class="w-1/3 text-right">
                                        <h5 class="font-[700]">0.00</h5>
                                        <small class="text-[60%] font-[300] ">NGN</small>
                                    </div>
                                </div>

                                <div class="flex justify-between">
                                    <div class="flex flex-col items-start w-2/3">
                                        <h3 class="font-[700]">Total Price</h3>
                                    </div>
                                     <div class="w-1/3 text-right">
                                        <h5 class="font-[700]">0.00</h5>
                                        <small class="text-[60%] font-[300] ">NGN</small>
                                    </div>
                                </div>




                            </div>

                            
                            <div class="flex justify-between">
                                <a href="#" class="text-[#1F242F] font-[700] text-[20px] flex gap-1 items-center">
                                    <img class="rotate-180 w-[15px]"  src="<?php echo e(asset('image/login.svg')); ?>" alt="lorem ipsum">
                                    BACK
                                </a>
                                <button class="bg-[#cc2121] text-white px-4 py-2 rounded-md">

                                    Check Out
                                </button>
                            </div>

                        </div>
                    </div>
                </form>
            </section>


            <section class="desktop-third-section">
                <div class="third-desktop-header">
                    <h1>Other Events You may like</h1>
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24"
                            fill="currentColor" class="size-6">
                            <path fill-rule="evenodd"
                                d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm-4.28 9.22a.75.75 0 0 0 0 1.06l3 3a.75.75 0 1 0 1.06-1.06l-1.72-1.72h5.69a.75.75 0 0 0 0-1.5h-5.69l1.72-1.72a.75.75 0 0 0-1.06-1.06l-3 3Z"
                                clip-rule="evenodd" />
                        </svg>
                        <!-- break -->
                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24"
                            fill="currentColor" class="size-6">
                            <path fill-rule="evenodd"
                                d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm4.28 10.28a.75.75 0 0 0 0-1.06l-3-3a.75.75 0 1 0-1.06 1.06l1.72 1.72H8.25a.75.75 0 0 0 0 1.5h5.69l-1.72 1.72a.75.75 0 1 0 1.06 1.06l3-3Z"
                                clip-rule="evenodd" />
                        </svg>
                    </span>
                </div>
                <div class="featured-card-grid">
                    <div class="party-card">
                        <img src="../../image/Rectangle 92 (1).png" alt="random">
                        <div class="card-text">
                            <h1>Davido Timeless</h1>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="13"
                                    viewBox="0 0 14 13" fill="none">
                                    <path
                                        d="M7 2.5V6.5L9.82667 9.32667M7 12.5C10.3137 12.5 13 9.81373 13 6.5C13 3.18629 10.3137 0.5 7 0.5C3.68629 0.5 1 3.18629 1 6.5C1 9.81373 3.68629 12.5 7 12.5Z"
                                        stroke="black" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                                <p>Dec 06 2024</p>
                            </span>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="13"
                                    viewBox="0 0 14 13" fill="none">
                                    <path
                                        d="M13 5.16667V3.16667C13 2.43029 12.3285 1.83333 11.5 1.83333H2.5C1.67157 1.83333 1 2.43029 1 3.16667V5.16667M13 5.16667V11.1667C13 11.9031 12.3285 12.5 11.5 12.5H2.5C1.67157 12.5 1 11.9031 1 11.1667V5.16667M13 5.16667H1M4 0.5V3.16667M10 0.5V3.16667"
                                        stroke="black" stroke-linecap="round" />
                                </svg>
                                <p>9:00PM (WAT) West africa Time</p>
                            </span>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="9" height="13" viewBox="0 0 9 13"
                                    fill="none">
                                    <path
                                        d="M4.54289 0.5C2.08319 0.5 0 2.59519 0 5.07664C0 7.67547 2.4147 10.3332 4.03888 12.2011C4.04525 12.2086 4.30776 12.5 4.63102 12.5H4.65952C4.98316 12.5 5.24379 12.2086 5.25016 12.2011C6.77421 10.4491 9.00028 7.55959 9.00028 5.07664C9.00028 2.59482 7.37536 0.5 4.54289 0.5ZM4.69327 11.6978C4.68015 11.711 4.66102 11.7256 4.64415 11.738C4.62689 11.726 4.60814 11.711 4.59427 11.6978L4.39814 11.4721C2.85834 9.70579 0.749648 7.28659 0.749648 5.07627C0.749648 3.0017 2.4867 1.24927 4.54252 1.24927C7.10347 1.24927 8.24988 3.17121 8.24988 5.07627C8.24988 6.75407 7.05322 8.98239 4.69327 11.6978ZM4.51327 2.7707C3.27085 2.7707 2.2632 3.77798 2.2632 5.02077C2.2632 6.26355 3.27085 7.27084 4.51327 7.27084C5.75568 7.27084 6.76334 6.26318 6.76334 5.02077C6.76334 3.77835 5.75605 2.7707 4.51327 2.7707ZM4.51327 6.52081C3.68599 6.52081 2.99597 5.83154 2.99597 5.00427C2.99597 4.17699 3.66874 3.50422 4.49602 3.50422C5.32367 3.50422 5.99606 4.17699 5.99606 5.00427C5.99644 5.83154 5.34092 6.52081 4.51327 6.52081Z"
                                        fill="black" />
                                </svg>
                                <p>36 o2 arena street, Ikeja, lagos state.</p>
                            </span>
                        </div>
                        <div class="card-bottom">
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="18"
                                    viewBox="0 0 16 18" fill="none">
                                    <path
                                        d="M8 18L5.21255 16.5094L2.63836 17.8857H2.4251C2.09861 17.8857 1.77966 17.826 1.47959 17.7082C1.19085 17.5939 0.930408 17.4322 0.709601 17.223C0.488794 17.0174 0.313281 16.7748 0.190611 16.5059C0.064166 16.2264 0 15.9311 0 15.6252V2.25879C0 1.95293 0.064166 1.65762 0.190611 1.37813C0.313281 1.10918 0.488795 0.866602 0.711489 0.660937C0.932295 0.453516 1.19273 0.291797 1.48148 0.177539C1.77778 0.0597656 2.09672 0 2.42321 0H13.5749C13.9014 0 14.2203 0.0597656 14.5204 0.177539C14.8092 0.291797 15.0696 0.453516 15.2904 0.662695C15.5112 0.868359 15.6867 1.11094 15.8094 1.37988C15.9358 1.65938 16 1.95469 16 2.26055V15.627C16 15.9328 15.9358 16.2281 15.8094 16.5076C15.6867 16.7766 15.5112 17.0191 15.2885 17.2248C15.0677 17.4322 14.8073 17.5939 14.5185 17.7082C14.2203 17.826 13.9014 17.8857 13.5749 17.8857H13.3616L10.7874 16.5094L8 18ZM10.7874 14.7902L13.7542 16.3775C13.8014 16.367 13.8485 16.3529 13.8957 16.3354C13.9939 16.2967 14.0826 16.2404 14.1581 16.1701C14.2354 16.098 14.2939 16.0172 14.3355 15.924C14.3789 15.8309 14.3996 15.7289 14.3996 15.6252V2.25879C14.3996 2.15508 14.3789 2.05313 14.3355 1.95996C14.2939 1.86855 14.2335 1.78594 14.1581 1.71563C14.0807 1.64355 13.9939 1.58906 13.8957 1.55039C13.7938 1.50996 13.6862 1.49063 13.5749 1.49063H2.42321C2.31187 1.49063 2.20429 1.50996 2.10238 1.55039C2.00425 1.58906 1.91555 1.64531 1.84006 1.71563C1.76268 1.7877 1.70418 1.86855 1.66266 1.96172C1.61925 2.05488 1.59849 2.15684 1.59849 2.26055V15.627C1.59849 15.7307 1.61925 15.8326 1.66266 15.9258C1.70418 16.0172 1.76457 16.0998 1.84006 16.1701C1.91743 16.2422 2.00425 16.2967 2.10238 16.3354C2.14768 16.3529 2.19486 16.367 2.24393 16.3775L5.21066 14.7902L8 16.2809L10.7874 14.7902Z"
                                        fill="#DB0101" />
                                    <path
                                        d="M7.19981 5.46504H3.99906C3.55744 5.46504 3.19887 5.13105 3.19887 4.71973C3.19887 4.3084 3.55744 3.97441 3.99906 3.97441H7.19981C7.64142 3.97441 8 4.3084 8 4.71973C8 5.13105 7.64142 5.46504 7.19981 5.46504ZM11.1989 8.57109H3.99906C3.55744 8.57109 3.19887 8.23711 3.19887 7.82578C3.19887 7.41445 3.55744 7.08047 3.99906 7.08047H11.2008C11.6424 7.08047 12.0009 7.41445 12.0009 7.82578C11.9991 8.23711 11.6424 8.57109 11.1989 8.57109Z"
                                        fill="black" />
                                </svg>
                                <p>₦ 2000</p>
                            </span>
                            <span>
                                <p>Get Ticket</p>
                                <svg class="get-ticket-icon" xmlns="http://www.w3.org/2000/svg" fill="none"
                                    width="20" height="20" viewBox="0 0 24 24" stroke-width="1.5"
                                    stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
                                </svg>
                            </span>
                        </div>
                        <!-- card icon -->
                        <svg class="party-ticket-card-icon" xmlns="http://www.w3.org/2000/svg" width="44"
                            height="44" viewBox="0 0 44 44" fill="none">
                            <rect width="44" height="44" rx="22" fill="#FF5454" />
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M26.3077 10C24.0986 10 22.3077 11.7909 22.3077 14C22.3077 14.2411 22.329 14.4772 22.37 14.7066L16.5476 18.7823C16.518 18.803 16.49 18.8251 16.4636 18.8485C15.7845 18.3169 14.9293 18 14 18C11.7909 18 10 19.7909 10 22C10 24.2091 11.7909 26 14 26C14.9293 26 15.7845 25.6831 16.4636 25.1515C16.49 25.1749 16.518 25.197 16.5476 25.2177L22.37 29.2934C22.329 29.5227 22.3077 29.7589 22.3077 30C22.3077 32.2091 24.0986 34 26.3077 34C28.5168 34 30.3077 32.2091 30.3077 30C30.3077 27.7909 28.5168 26 26.3077 26C25.0119 26 23.8601 26.6161 23.1291 27.5713L17.6161 23.7121C17.8623 23.1931 18 22.6127 18 22C18 21.3873 17.8623 20.8069 17.6161 20.2879L23.1291 16.4287C23.8601 17.3839 25.0119 18 26.3077 18C28.5168 18 30.3077 16.2091 30.3077 14C30.3077 11.7909 28.5168 10 26.3077 10ZM24.1538 14C24.1538 12.8105 25.1182 11.8462 26.3077 11.8462C27.4972 11.8462 28.4615 12.8105 28.4615 14C28.4615 15.1895 27.4972 16.1538 26.3077 16.1538C25.1182 16.1538 24.1538 15.1895 24.1538 14ZM14 19.8462C12.8105 19.8462 11.8462 20.8105 11.8462 22C11.8462 23.1895 12.8105 24.1538 14 24.1538C15.1895 24.1538 16.1538 23.1895 16.1538 22C16.1538 20.8105 15.1895 19.8462 14 19.8462ZM26.3077 27.8462C25.1182 27.8462 24.1538 28.8105 24.1538 30C24.1538 31.1895 25.1182 32.1538 26.3077 32.1538C27.4972 32.1538 28.4615 31.1895 28.4615 30C28.4615 28.8105 27.4972 27.8462 26.3077 27.8462Z"
                                fill="white" />
                        </svg>
                        <!-- card icon -->
                    </div>
                    <!-- break -->
                    <div class="party-card">
                        <img src="../../image/Rectangle 92 (1).png" alt="random">
                        <div class="card-text">
                            <h1>Davido Timeless</h1>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="13"
                                    viewBox="0 0 14 13" fill="none">
                                    <path
                                        d="M7 2.5V6.5L9.82667 9.32667M7 12.5C10.3137 12.5 13 9.81373 13 6.5C13 3.18629 10.3137 0.5 7 0.5C3.68629 0.5 1 3.18629 1 6.5C1 9.81373 3.68629 12.5 7 12.5Z"
                                        stroke="black" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                                <p>Dec 06 2024</p>
                            </span>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="13"
                                    viewBox="0 0 14 13" fill="none">
                                    <path
                                        d="M13 5.16667V3.16667C13 2.43029 12.3285 1.83333 11.5 1.83333H2.5C1.67157 1.83333 1 2.43029 1 3.16667V5.16667M13 5.16667V11.1667C13 11.9031 12.3285 12.5 11.5 12.5H2.5C1.67157 12.5 1 11.9031 1 11.1667V5.16667M13 5.16667H1M4 0.5V3.16667M10 0.5V3.16667"
                                        stroke="black" stroke-linecap="round" />
                                </svg>
                                <p>9:00PM (WAT) West africa Time</p>
                            </span>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="9" height="13" viewBox="0 0 9 13"
                                    fill="none">
                                    <path
                                        d="M4.54289 0.5C2.08319 0.5 0 2.59519 0 5.07664C0 7.67547 2.4147 10.3332 4.03888 12.2011C4.04525 12.2086 4.30776 12.5 4.63102 12.5H4.65952C4.98316 12.5 5.24379 12.2086 5.25016 12.2011C6.77421 10.4491 9.00028 7.55959 9.00028 5.07664C9.00028 2.59482 7.37536 0.5 4.54289 0.5ZM4.69327 11.6978C4.68015 11.711 4.66102 11.7256 4.64415 11.738C4.62689 11.726 4.60814 11.711 4.59427 11.6978L4.39814 11.4721C2.85834 9.70579 0.749648 7.28659 0.749648 5.07627C0.749648 3.0017 2.4867 1.24927 4.54252 1.24927C7.10347 1.24927 8.24988 3.17121 8.24988 5.07627C8.24988 6.75407 7.05322 8.98239 4.69327 11.6978ZM4.51327 2.7707C3.27085 2.7707 2.2632 3.77798 2.2632 5.02077C2.2632 6.26355 3.27085 7.27084 4.51327 7.27084C5.75568 7.27084 6.76334 6.26318 6.76334 5.02077C6.76334 3.77835 5.75605 2.7707 4.51327 2.7707ZM4.51327 6.52081C3.68599 6.52081 2.99597 5.83154 2.99597 5.00427C2.99597 4.17699 3.66874 3.50422 4.49602 3.50422C5.32367 3.50422 5.99606 4.17699 5.99606 5.00427C5.99644 5.83154 5.34092 6.52081 4.51327 6.52081Z"
                                        fill="black" />
                                </svg>
                                <p>36 o2 arena street, Ikeja, lagos state.</p>
                            </span>
                        </div>
                        <div class="card-bottom">
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="18"
                                    viewBox="0 0 16 18" fill="none">
                                    <path
                                        d="M8 18L5.21255 16.5094L2.63836 17.8857H2.4251C2.09861 17.8857 1.77966 17.826 1.47959 17.7082C1.19085 17.5939 0.930408 17.4322 0.709601 17.223C0.488794 17.0174 0.313281 16.7748 0.190611 16.5059C0.064166 16.2264 0 15.9311 0 15.6252V2.25879C0 1.95293 0.064166 1.65762 0.190611 1.37813C0.313281 1.10918 0.488795 0.866602 0.711489 0.660937C0.932295 0.453516 1.19273 0.291797 1.48148 0.177539C1.77778 0.0597656 2.09672 0 2.42321 0H13.5749C13.9014 0 14.2203 0.0597656 14.5204 0.177539C14.8092 0.291797 15.0696 0.453516 15.2904 0.662695C15.5112 0.868359 15.6867 1.11094 15.8094 1.37988C15.9358 1.65938 16 1.95469 16 2.26055V15.627C16 15.9328 15.9358 16.2281 15.8094 16.5076C15.6867 16.7766 15.5112 17.0191 15.2885 17.2248C15.0677 17.4322 14.8073 17.5939 14.5185 17.7082C14.2203 17.826 13.9014 17.8857 13.5749 17.8857H13.3616L10.7874 16.5094L8 18ZM10.7874 14.7902L13.7542 16.3775C13.8014 16.367 13.8485 16.3529 13.8957 16.3354C13.9939 16.2967 14.0826 16.2404 14.1581 16.1701C14.2354 16.098 14.2939 16.0172 14.3355 15.924C14.3789 15.8309 14.3996 15.7289 14.3996 15.6252V2.25879C14.3996 2.15508 14.3789 2.05313 14.3355 1.95996C14.2939 1.86855 14.2335 1.78594 14.1581 1.71563C14.0807 1.64355 13.9939 1.58906 13.8957 1.55039C13.7938 1.50996 13.6862 1.49063 13.5749 1.49063H2.42321C2.31187 1.49063 2.20429 1.50996 2.10238 1.55039C2.00425 1.58906 1.91555 1.64531 1.84006 1.71563C1.76268 1.7877 1.70418 1.86855 1.66266 1.96172C1.61925 2.05488 1.59849 2.15684 1.59849 2.26055V15.627C1.59849 15.7307 1.61925 15.8326 1.66266 15.9258C1.70418 16.0172 1.76457 16.0998 1.84006 16.1701C1.91743 16.2422 2.00425 16.2967 2.10238 16.3354C2.14768 16.3529 2.19486 16.367 2.24393 16.3775L5.21066 14.7902L8 16.2809L10.7874 14.7902Z"
                                        fill="#DB0101" />
                                    <path
                                        d="M7.19981 5.46504H3.99906C3.55744 5.46504 3.19887 5.13105 3.19887 4.71973C3.19887 4.3084 3.55744 3.97441 3.99906 3.97441H7.19981C7.64142 3.97441 8 4.3084 8 4.71973C8 5.13105 7.64142 5.46504 7.19981 5.46504ZM11.1989 8.57109H3.99906C3.55744 8.57109 3.19887 8.23711 3.19887 7.82578C3.19887 7.41445 3.55744 7.08047 3.99906 7.08047H11.2008C11.6424 7.08047 12.0009 7.41445 12.0009 7.82578C11.9991 8.23711 11.6424 8.57109 11.1989 8.57109Z"
                                        fill="black" />
                                </svg>
                                <p>₦ 2000</p>
                            </span>
                            <span>
                                <p>Get Ticket</p>
                                <svg class="get-ticket-icon" xmlns="http://www.w3.org/2000/svg" fill="none"
                                    width="20" height="20" viewBox="0 0 24 24" stroke-width="1.5"
                                    stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
                                </svg>
                            </span>
                        </div>
                        <!-- card icon -->
                        <svg class="party-ticket-card-icon" xmlns="http://www.w3.org/2000/svg" width="44"
                            height="44" viewBox="0 0 44 44" fill="none">
                            <rect width="44" height="44" rx="22" fill="#FF5454" />
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M26.3077 10C24.0986 10 22.3077 11.7909 22.3077 14C22.3077 14.2411 22.329 14.4772 22.37 14.7066L16.5476 18.7823C16.518 18.803 16.49 18.8251 16.4636 18.8485C15.7845 18.3169 14.9293 18 14 18C11.7909 18 10 19.7909 10 22C10 24.2091 11.7909 26 14 26C14.9293 26 15.7845 25.6831 16.4636 25.1515C16.49 25.1749 16.518 25.197 16.5476 25.2177L22.37 29.2934C22.329 29.5227 22.3077 29.7589 22.3077 30C22.3077 32.2091 24.0986 34 26.3077 34C28.5168 34 30.3077 32.2091 30.3077 30C30.3077 27.7909 28.5168 26 26.3077 26C25.0119 26 23.8601 26.6161 23.1291 27.5713L17.6161 23.7121C17.8623 23.1931 18 22.6127 18 22C18 21.3873 17.8623 20.8069 17.6161 20.2879L23.1291 16.4287C23.8601 17.3839 25.0119 18 26.3077 18C28.5168 18 30.3077 16.2091 30.3077 14C30.3077 11.7909 28.5168 10 26.3077 10ZM24.1538 14C24.1538 12.8105 25.1182 11.8462 26.3077 11.8462C27.4972 11.8462 28.4615 12.8105 28.4615 14C28.4615 15.1895 27.4972 16.1538 26.3077 16.1538C25.1182 16.1538 24.1538 15.1895 24.1538 14ZM14 19.8462C12.8105 19.8462 11.8462 20.8105 11.8462 22C11.8462 23.1895 12.8105 24.1538 14 24.1538C15.1895 24.1538 16.1538 23.1895 16.1538 22C16.1538 20.8105 15.1895 19.8462 14 19.8462ZM26.3077 27.8462C25.1182 27.8462 24.1538 28.8105 24.1538 30C24.1538 31.1895 25.1182 32.1538 26.3077 32.1538C27.4972 32.1538 28.4615 31.1895 28.4615 30C28.4615 28.8105 27.4972 27.8462 26.3077 27.8462Z"
                                fill="white" />
                        </svg>
                        <!-- card icon -->
                    </div>
                    <!-- break -->
                    <div class="party-card">
                        <img src="../../image/Rectangle 92 (1).png" alt="random">
                        <div class="card-text">
                            <h1>Davido Timeless</h1>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="13"
                                    viewBox="0 0 14 13" fill="none">
                                    <path
                                        d="M7 2.5V6.5L9.82667 9.32667M7 12.5C10.3137 12.5 13 9.81373 13 6.5C13 3.18629 10.3137 0.5 7 0.5C3.68629 0.5 1 3.18629 1 6.5C1 9.81373 3.68629 12.5 7 12.5Z"
                                        stroke="black" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                                <p>Dec 06 2024</p>
                            </span>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="13"
                                    viewBox="0 0 14 13" fill="none">
                                    <path
                                        d="M13 5.16667V3.16667C13 2.43029 12.3285 1.83333 11.5 1.83333H2.5C1.67157 1.83333 1 2.43029 1 3.16667V5.16667M13 5.16667V11.1667C13 11.9031 12.3285 12.5 11.5 12.5H2.5C1.67157 12.5 1 11.9031 1 11.1667V5.16667M13 5.16667H1M4 0.5V3.16667M10 0.5V3.16667"
                                        stroke="black" stroke-linecap="round" />
                                </svg>
                                <p>9:00PM (WAT) West africa Time</p>
                            </span>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="9" height="13" viewBox="0 0 9 13"
                                    fill="none">
                                    <path
                                        d="M4.54289 0.5C2.08319 0.5 0 2.59519 0 5.07664C0 7.67547 2.4147 10.3332 4.03888 12.2011C4.04525 12.2086 4.30776 12.5 4.63102 12.5H4.65952C4.98316 12.5 5.24379 12.2086 5.25016 12.2011C6.77421 10.4491 9.00028 7.55959 9.00028 5.07664C9.00028 2.59482 7.37536 0.5 4.54289 0.5ZM4.69327 11.6978C4.68015 11.711 4.66102 11.7256 4.64415 11.738C4.62689 11.726 4.60814 11.711 4.59427 11.6978L4.39814 11.4721C2.85834 9.70579 0.749648 7.28659 0.749648 5.07627C0.749648 3.0017 2.4867 1.24927 4.54252 1.24927C7.10347 1.24927 8.24988 3.17121 8.24988 5.07627C8.24988 6.75407 7.05322 8.98239 4.69327 11.6978ZM4.51327 2.7707C3.27085 2.7707 2.2632 3.77798 2.2632 5.02077C2.2632 6.26355 3.27085 7.27084 4.51327 7.27084C5.75568 7.27084 6.76334 6.26318 6.76334 5.02077C6.76334 3.77835 5.75605 2.7707 4.51327 2.7707ZM4.51327 6.52081C3.68599 6.52081 2.99597 5.83154 2.99597 5.00427C2.99597 4.17699 3.66874 3.50422 4.49602 3.50422C5.32367 3.50422 5.99606 4.17699 5.99606 5.00427C5.99644 5.83154 5.34092 6.52081 4.51327 6.52081Z"
                                        fill="black" />
                                </svg>
                                <p>36 o2 arena street, Ikeja, lagos state.</p>
                            </span>
                        </div>
                        <div class="card-bottom">
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="18"
                                    viewBox="0 0 16 18" fill="none">
                                    <path
                                        d="M8 18L5.21255 16.5094L2.63836 17.8857H2.4251C2.09861 17.8857 1.77966 17.826 1.47959 17.7082C1.19085 17.5939 0.930408 17.4322 0.709601 17.223C0.488794 17.0174 0.313281 16.7748 0.190611 16.5059C0.064166 16.2264 0 15.9311 0 15.6252V2.25879C0 1.95293 0.064166 1.65762 0.190611 1.37813C0.313281 1.10918 0.488795 0.866602 0.711489 0.660937C0.932295 0.453516 1.19273 0.291797 1.48148 0.177539C1.77778 0.0597656 2.09672 0 2.42321 0H13.5749C13.9014 0 14.2203 0.0597656 14.5204 0.177539C14.8092 0.291797 15.0696 0.453516 15.2904 0.662695C15.5112 0.868359 15.6867 1.11094 15.8094 1.37988C15.9358 1.65938 16 1.95469 16 2.26055V15.627C16 15.9328 15.9358 16.2281 15.8094 16.5076C15.6867 16.7766 15.5112 17.0191 15.2885 17.2248C15.0677 17.4322 14.8073 17.5939 14.5185 17.7082C14.2203 17.826 13.9014 17.8857 13.5749 17.8857H13.3616L10.7874 16.5094L8 18ZM10.7874 14.7902L13.7542 16.3775C13.8014 16.367 13.8485 16.3529 13.8957 16.3354C13.9939 16.2967 14.0826 16.2404 14.1581 16.1701C14.2354 16.098 14.2939 16.0172 14.3355 15.924C14.3789 15.8309 14.3996 15.7289 14.3996 15.6252V2.25879C14.3996 2.15508 14.3789 2.05313 14.3355 1.95996C14.2939 1.86855 14.2335 1.78594 14.1581 1.71563C14.0807 1.64355 13.9939 1.58906 13.8957 1.55039C13.7938 1.50996 13.6862 1.49063 13.5749 1.49063H2.42321C2.31187 1.49063 2.20429 1.50996 2.10238 1.55039C2.00425 1.58906 1.91555 1.64531 1.84006 1.71563C1.76268 1.7877 1.70418 1.86855 1.66266 1.96172C1.61925 2.05488 1.59849 2.15684 1.59849 2.26055V15.627C1.59849 15.7307 1.61925 15.8326 1.66266 15.9258C1.70418 16.0172 1.76457 16.0998 1.84006 16.1701C1.91743 16.2422 2.00425 16.2967 2.10238 16.3354C2.14768 16.3529 2.19486 16.367 2.24393 16.3775L5.21066 14.7902L8 16.2809L10.7874 14.7902Z"
                                        fill="#DB0101" />
                                    <path
                                        d="M7.19981 5.46504H3.99906C3.55744 5.46504 3.19887 5.13105 3.19887 4.71973C3.19887 4.3084 3.55744 3.97441 3.99906 3.97441H7.19981C7.64142 3.97441 8 4.3084 8 4.71973C8 5.13105 7.64142 5.46504 7.19981 5.46504ZM11.1989 8.57109H3.99906C3.55744 8.57109 3.19887 8.23711 3.19887 7.82578C3.19887 7.41445 3.55744 7.08047 3.99906 7.08047H11.2008C11.6424 7.08047 12.0009 7.41445 12.0009 7.82578C11.9991 8.23711 11.6424 8.57109 11.1989 8.57109Z"
                                        fill="black" />
                                </svg>
                                <p>₦ 2000</p>
                            </span>
                            <span>
                                <p>Get Ticket</p>
                                <svg class="get-ticket-icon" xmlns="http://www.w3.org/2000/svg" fill="none"
                                    width="20" height="20" viewBox="0 0 24 24" stroke-width="1.5"
                                    stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
                                </svg>
                            </span>
                        </div>
                        <!-- card icon -->
                        <svg class="party-ticket-card-icon" xmlns="http://www.w3.org/2000/svg" width="44"
                            height="44" viewBox="0 0 44 44" fill="none">
                            <rect width="44" height="44" rx="22" fill="#FF5454" />
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M26.3077 10C24.0986 10 22.3077 11.7909 22.3077 14C22.3077 14.2411 22.329 14.4772 22.37 14.7066L16.5476 18.7823C16.518 18.803 16.49 18.8251 16.4636 18.8485C15.7845 18.3169 14.9293 18 14 18C11.7909 18 10 19.7909 10 22C10 24.2091 11.7909 26 14 26C14.9293 26 15.7845 25.6831 16.4636 25.1515C16.49 25.1749 16.518 25.197 16.5476 25.2177L22.37 29.2934C22.329 29.5227 22.3077 29.7589 22.3077 30C22.3077 32.2091 24.0986 34 26.3077 34C28.5168 34 30.3077 32.2091 30.3077 30C30.3077 27.7909 28.5168 26 26.3077 26C25.0119 26 23.8601 26.6161 23.1291 27.5713L17.6161 23.7121C17.8623 23.1931 18 22.6127 18 22C18 21.3873 17.8623 20.8069 17.6161 20.2879L23.1291 16.4287C23.8601 17.3839 25.0119 18 26.3077 18C28.5168 18 30.3077 16.2091 30.3077 14C30.3077 11.7909 28.5168 10 26.3077 10ZM24.1538 14C24.1538 12.8105 25.1182 11.8462 26.3077 11.8462C27.4972 11.8462 28.4615 12.8105 28.4615 14C28.4615 15.1895 27.4972 16.1538 26.3077 16.1538C25.1182 16.1538 24.1538 15.1895 24.1538 14ZM14 19.8462C12.8105 19.8462 11.8462 20.8105 11.8462 22C11.8462 23.1895 12.8105 24.1538 14 24.1538C15.1895 24.1538 16.1538 23.1895 16.1538 22C16.1538 20.8105 15.1895 19.8462 14 19.8462ZM26.3077 27.8462C25.1182 27.8462 24.1538 28.8105 24.1538 30C24.1538 31.1895 25.1182 32.1538 26.3077 32.1538C27.4972 32.1538 28.4615 31.1895 28.4615 30C28.4615 28.8105 27.4972 27.8462 26.3077 27.8462Z"
                                fill="white" />
                        </svg>
                        <!-- card icon -->
                    </div>
                </div>
            </section>
        </div>


        <!-- desktop section ends here -->
        
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Websites\901-ticket\900-ticket\resources\views/pages/events/event.blade.php ENDPATH**/ ?>