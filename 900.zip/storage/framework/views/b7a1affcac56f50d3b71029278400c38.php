<?php $__env->startSection('title', 'Register With Us'); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="w-full mx-auto">
        <section class="md:px-8 md:py-8 py-4  w-[80%] mx-auto  flex items-center justify-center">
            <div class="hidden md:block w-1/2 ">
                <img class="object-cover w-full h-full" src="<?php echo e(asset('image/profilePop1-v3.jpg')); ?>" alt="lorem ipsum">
            </div>
            <div class="w-[100%] md:w-1/2 ">
                
                <div class="bg-white px-3 py-2">


                    <div class="flex gap-3">

                        <a id="" href="<?php echo e(route('index.login')); ?>"
                            class="signupLink cursor-pointer font-[600]   bg-red-700 text-white px-2 py- md:px-4 md:py-2 rounded-md hover:bg-red-900">Login</a>

                        <a id="" href="<?php echo e(route('index.register')); ?>"
                            class="loginLink cursor-pointer font-[600]   bg-red-700 text-white px-2 py- md:px-4 md:py-2 rounded-md hover:bg-red-900">Register</a>
                    </div>

                </div>


                
                <div id=""
                    class="signupSection  h-fit  md:w-full flex-col gap-2 rounded-b-md bg-white px-3 pb-2 shadow-lg">
                    <div>
                        <form method="POST" class="flex signupForm flex-col gap-2" action="<?php echo e(route('register.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="login-field flex flex-col gap-1">
                                <label class="font-[500]" for="firstName">First Name</label>
                                <input class="input" type="text" name="firstname" value="<?php echo e(old('firstname')); ?>"
                                    placeholder="Enter Firstname">
                                <span class="text-[12px] font-[200] text-red-700">
                                    <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="login-field flex flex-col gap-1">
                                <label class="font-[500]" for="lastName">Surname</label>
                                <input class="input" value="<?php echo e(old('lastname')); ?>" type="text" name="lastname"
                                    placeholder="Enter a Last name">
                                <span class="text-[12px] font-[200] text-red-700">
                                    <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="login-field flex flex-col gap-1">
                                <label class="font-[500]" for="address">Address</label>
                                <input class="input" type="text" name="address" value="<?php echo e(old('address')); ?>"
                                    placeholder="Enter Address">
                                <span class="text-[12px] font-[200] text-red-700">
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="login-field flex flex-col gap-1">
                                <label class="font-[500]" for="email">Email</label>
                                <input title="Eg: mark@yokomail.com" class="input" type="email" name="email"
                                    value="<?php echo e(old('email')); ?>" placeholder="Enter your Email">
                                <span class="text-[12px] font-[200] text-red-700">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="login-field flex flex-col gap-1">
                                <label class="font-[500]" for="email">Phone Number</label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 start-0 top-0 flex items-center ps-3.5 pointer-events-none">
                                        <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                                            xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 19 18">
                                            <path
                                                d="M18 13.446a3.02 3.02 0 0 0-.946-1.985l-1.4-1.4a3.054 3.054 0 0 0-4.218 0l-.7.7a.983.983 0 0 1-1.39 0l-2.1-2.1a.983.983 0 0 1 0-1.389l.7-.7a2.98 2.98 0 0 0 0-4.217l-1.4-1.4a2.824 2.824 0 0 0-4.218 0c-3.619 3.619-3 8.229 1.752 12.979C6.785 16.639 9.45 18 11.912 18a7.175 7.175 0 0 0 5.139-2.325A2.9 2.9 0 0 0 18 13.446Z" />
                                        </svg>
                                    </div> <input style="padding-left: 35px !important;" title="+234..." class="input " value="<?php echo e(old('phone')); ?>"
                                        type="tel" name="phone" placeholder="+234....">
                                </div>
                                <span class="text-[12px] font-[200] text-red-700">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="flex flex-col gap-1">
                                <label class="font-[500]" for="password">Password</label>
                                <div class="flex items-center">
                                    <input class="signupPassword passMain input" id="password" type="password" name="password"
                                        placeholder="Enter Password">
                                    <input type="checkbox" id="" class="toggleSignupPassword ml-2"
                                        onclick="togglePasswordVisibility('signup')">
                                    <label for="toggleSignupPassword" class="cursor-pointer">
                                        <svg fill="#8b0003" width="34px" height="34px" viewBox="0 0 512 512"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                            <g id="SVGRepo_iconCarrier">
                                                <g id="Password">
                                                    <path
                                                        d="M391,233.9478H121a45.1323,45.1323,0,0,0-45,45v162a45.1323,45.1323,0,0,0,45,45H391a45.1323,45.1323,0,0,0,45-45v-162A45.1323,45.1323,0,0,0,391,233.9478ZM184.123,369.3794a9.8954,9.8954,0,1,1-9.8964,17.1387l-16.33-9.4287v18.8593a9.8965,9.8965,0,0,1-19.793,0V377.0894l-16.33,9.4287a9.8954,9.8954,0,0,1-9.8964-17.1387l16.3344-9.4307-16.3344-9.4306a9.8954,9.8954,0,0,1,9.8964-17.1387l16.33,9.4282V323.9487a9.8965,9.8965,0,0,1,19.793,0v18.8589l16.33-9.4282a9.8954,9.8954,0,0,1,9.8964,17.1387l-16.3344,9.4306Zm108,0a9.8954,9.8954,0,1,1-9.8964,17.1387l-16.33-9.4287v18.8593a9.8965,9.8965,0,0,1-19.793,0V377.0894l-16.33,9.4287a9.8954,9.8954,0,0,1-9.8964-17.1387l16.3344-9.4307-16.3344-9.4306a9.8954,9.8954,0,0,1,9.8964-17.1387l16.33,9.4282V323.9487a9.8965,9.8965,0,0,1,19.793,0v18.8589l16.33-9.4282a9.8954,9.8954,0,0,1,9.8964,17.1387l-16.3344,9.4306Zm108,0a9.8954,9.8954,0,1,1-9.8964,17.1387l-16.33-9.4287v18.8593a9.8965,9.8965,0,0,1-19.793,0V377.0894l-16.33,9.4287a9.8954,9.8954,0,0,1-9.8964-17.1387l16.3344-9.4307-16.3344-9.4306a9.8954,9.8954,0,0,1,9.8964-17.1387l16.33,9.4282V323.9487a9.8965,9.8965,0,0,1,19.793,0v18.8589l16.33-9.4282a9.8954,9.8954,0,0,1,9.8964,17.1387l-16.3344,9.4306Z">
                                                    </path>
                                                    <path
                                                        d="M157.8965,143.9487a98.1035,98.1035,0,1,1,196.207,0V214.147h19.793V143.9487a117.8965,117.8965,0,0,0-235.793,0V214.147h19.793Z">
                                                    </path>
                                                </g>
                                            </g>
                                        </svg>
                                    </label>



                                </div>
                                <span class="text-[12px] font-[200] text-red-700">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="flex flex-col gap-1">
                                <label class="font-[500]" for="password">Confirm Password</label>
                                <div class="flex items-center">
                                    <input class="signupPassword confirmPassword input" id="password_confirmation"
                                        type="password" name="password_confirmation" placeholder="Confirm  Password">




                                </div>
                                <span class="text-[12px] font-[200] text-red-700">
                                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <button
                                class="hover:red-alt-800 w-full rounded-md bg-red-alt-700 py-2 text-center uppercase text-white submit"
                                type="submit">
                                Sign Up
                            </button>
                        </form>

                        
                    </div>
                </div>
            </div>

        </section>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Websites\901-ticket\900-ticket\resources\views/verify/register.blade.php ENDPATH**/ ?>