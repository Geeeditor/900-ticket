<?php $__env->startSection('content'); ?>
    <section>
        <div class="flex md:gap-3">
            <div class="w-full md:w-[30%]">
                <div class="w-full max-h-[250px]">
                    <img class="object-contain max-h-[250px]" src="<?php echo e(asset('storage/' . $event->hero_image)); ?>" alt="lorem ipsum">
                </div>

                <div class="flex flex-col gap-1 py-4">


                    <p class="flex gap-2 text-[14px]">
                        <img src="<?php echo e(asset('image/date.svg')); ?>" alt="lorem ipsum"> <?php echo e(\Carbon\Carbon::parse($event->date)->format('F j, Y')); ?>

                    </p>
                    <p class="flex gap-2 text-[14px]">
                        <img src="<?php echo e(asset('image/clock.svg')); ?>" alt="lorem ipsum"> 12:20
                    </p>
                    <p class="flex gap-2 text-[14px]">
                        <img src="<?php echo e(asset('image/map-pin.svg')); ?>" alt="lorem ipsum"> <?php echo e($event->location); ?>

                    </p>
                    <a class="flex gap-2 text-[14px]" href="<?php echo e($event->map_link); ?>">
                        <img src="<?php echo e(asset('image/link.svg')); ?>" alt="lorem ipsum">
                        <?php echo e($event->map_link); ?>

                    </a>
                </div>
            </div>

            <div class="w-full md:w-[70%]">
                <h1 class="font-[700] text-[23px] uppercase mb-2">
                    <?php echo e($event->title); ?>

                </h1>
                <p>
                    <?php echo nl2br(e($event->description)); ?>

                </p>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Websites\901-ticket\900-ticket\resources\views/admin/pages/900Events/show.blade.php ENDPATH**/ ?>