@extends('layouts.admin')
@section('content')
    View Events
@endsection
