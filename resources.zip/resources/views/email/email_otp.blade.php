<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Your OTP Code</title>
</head>
<body>
    <p>Hello, {{$firstname}}</p>
    <p>Your One-Time Password (OTP) is: <strong>{{$otp}}</strong></p>
    <p>Please use this code to complete your registration. This OTP will expire in less than 5min</p>
    <p>Thank You!</p>
</body>
</html>
